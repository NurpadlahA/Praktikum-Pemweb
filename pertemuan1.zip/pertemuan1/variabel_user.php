<?php
// definisi varibel
$nama = 'Nurpadlah Apipah';
$umur =18;
$berat = 50;

echo 'nama :'.$nama;
echo '<br/> umur:'.$umur. 'kg';
echo '<br/> berat:'.$berat. 'kg';

echo "<br/>Hello $nama Apa kabar";
echo "<br/>Hai Nama sata $nama Umur saya $umur Berat badan saya $berat kg. salam kenal semuanya";